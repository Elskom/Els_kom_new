Option Strict Off
Option Explicit On
Module Module1
	Public Const MAX_PATH As Integer = 260
	Private Const ERROR_NO_MORE_FILES As Integer = 18
	Private Const FILE_ATTRIBUTE_NORMAL As Integer = &H80
	
	Private Structure FILETIME
		Dim dwLowDateTime As Integer
		Dim dwHighDateTime As Integer
	End Structure
	
	Private Structure WIN32_FIND_DATA
		Dim dwFileAttributes As Integer
		Dim ftCreationTime As FILETIME
		Dim ftLastAccessTime As FILETIME
		Dim ftLastWriteTime As FILETIME
		Dim nFileSizeHigh As Integer
		Dim nFileSizeLow As Integer
		Dim dwReserved0 As Integer
		Dim dwReserved1 As Integer
		'UPGRADE_WARNING: Fixed-length string size must fit in the buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="3C1E4426-0B80-443E-B943-0627CD55D48B"'
		<VBFixedString(MAX_PATH),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=MAX_PATH)> Public cFileName() As Char
		'UPGRADE_WARNING: Fixed-length string size must fit in the buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="3C1E4426-0B80-443E-B943-0627CD55D48B"'
		<VBFixedString(14),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=14)> Public cAlternate() As Char
	End Structure
	
	'UPGRADE_WARNING: Structure WIN32_FIND_DATA may require marshalling attributes to be passed as an argument in this Declare statement. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="C429C3A5-5D47-4CD9-8F51-74A1616405DC"'
	Private Declare Function FindFirstFile Lib "kernel32"  Alias "FindFirstFileA"(ByVal lpFileName As String, ByRef lpFindFileData As WIN32_FIND_DATA) As Integer
	Private Declare Function FindClose Lib "kernel32" (ByVal hFindFile As Integer) As Integer
	'UPGRADE_WARNING: Structure WIN32_FIND_DATA may require marshalling attributes to be passed as an argument in this Declare statement. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="C429C3A5-5D47-4CD9-8F51-74A1616405DC"'
	Private Declare Function FindNextFile Lib "kernel32"  Alias "FindNextFileA"(ByVal hFindFile As Integer, ByRef lpFindFileData As WIN32_FIND_DATA) As Integer
	
	Public Function FileExists(ByVal sFile As String) As Boolean
		Dim lpFindFileData As WIN32_FIND_DATA
		Dim lFileHandle As Integer
		Dim lRet As Integer
		Dim sTemp As String
		Dim sFileExtension As String
		Dim sFileName As String
		Dim sFileData() As String
		Dim sFileToCompare As String
		
		If IsDirectory(sFile) = True Then
			sFile = AddSlash(sFile) & "*.*"
		End If
		
		If InStr(sFile, ".") > 0 Then
			sFileToCompare = GetFileTitle(sFile)
			sFileData = Split(sFileToCompare, ".")
			sFileName = sFileData(0)
			sFileExtension = sFileData(1)
		Else
			Exit Function
		End If
		
		' get a file handle
		lFileHandle = FindFirstFile(sFile, lpFindFileData)
		If lFileHandle <> -1 Then
			If sFileName = "*" Or sFileExtension = "*" Then
				FileExists = True
			Else
				Do Until lRet = ERROR_NO_MORE_FILES
					' if it is a file
					'UPGRADE_ISSUE: Unable to determine which constant to upgrade vbNormal to. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="B3B44E51-B5F1-4FD7-AA29-CAD31B71F487"'
					If (lpFindFileData.dwFileAttributes And FILE_ATTRIBUTE_NORMAL) = vbNormal Then
						sTemp = StrConv(RemoveNull(lpFindFileData.cFileName), VbStrConv.ProperCase)
						
						'remove LCase$ if you want the search to be case sensitive
						If LCase(sTemp) = LCase(sFileToCompare) Then
							FileExists = True ' file found
							Exit Do
						End If
					End If
					'based on the file handle iterate through all files and dirs
					lRet = FindNextFile(lFileHandle, lpFindFileData)
					If lRet = 0 Then Exit Do
				Loop 
			End If
		End If
		
		' close the file handle
		lRet = FindClose(lFileHandle)
	End Function
	
	Private Function IsDirectory(ByVal sFile As String) As Boolean
		On Error Resume Next
		IsDirectory = ((GetAttr(sFile) And FileAttribute.Directory) = FileAttribute.Directory)
	End Function
	
	Private Function RemoveNull(ByVal strString As String) As String
		Dim intZeroPos As Short
		
		intZeroPos = InStr(strString, Chr(0))
		If intZeroPos > 0 Then
			RemoveNull = Left(strString, intZeroPos - 1)
		Else
			RemoveNull = strString
		End If
	End Function
	
	Public Function GetFileTitle(ByVal sFileName As String) As String
		GetFileTitle = Right(sFileName, Len(sFileName) - InStrRev(sFileName, "\"))
	End Function
	
	Public Function AddSlash(ByVal strDirectory As String) As String
		If InStrRev(strDirectory, "\") <> Len(strDirectory) Then
			strDirectory = strDirectory & "\"
		End If
		AddSlash = strDirectory
	End Function
End Module