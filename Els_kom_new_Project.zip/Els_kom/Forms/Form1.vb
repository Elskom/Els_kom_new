Option Strict Off
Option Explicit On
Friend Class Form1
	Inherits System.Windows.Forms.Form
	'User-defined variable to pass to the Shell_NotiyIcon function
	'Private Structure NOTIFYICONDATA
	'	Dim cbSize As Long
	'	Dim hwnd As Long
	'	Dim uId As Long
	'	Dim uFlags As Long
	'	Dim uCallBackMessage As Long
	'	Dim hIcon As Icon
	'	Dim szTip As String
	'End Structure

	'Constants for the Shell_NotifyIcon function
	'Private Const NIM_ADD As Integer = &H0
	'Private Const NIM_MODIFY As Integer = &H1
	'Private Const NIM_DELETE As Integer = &H2
	'
	'Private Const WM_MOUSEMOVE As Integer = &H200
	'
	'Private Const NIF_MESSAGE As Integer = &H1
	'Private Const NIF_ICON As Integer = &H2
	'Private Const NIF_TIP As Integer = &H4
	'
	'Private Const WM_LBUTTONDBLCLK As Integer = &H203
	'Private Const WM_LBUTTONDOWN As Integer = &H201
	'Private Const WM_LBUTTONUP As Integer = &H202
	'Private Const WM_RBUTTONDBLCLK As Integer = &H206
	'Private Const WM_RBUTTONDOWN As Integer = &H204
	'Private Const WM_RBUTTONUP As Integer = &H205
	'
	'Declare the API function call
	'Private Declare Function Shell_NotifyIcon Lib "shell32" Alias "Shell_NotifyIconA" (ByVal dwMessage As Integer, ByRef pnid As NOTIFYICONDATA) As Boolean
	'
	'Private Declare Function EnumWindows Lib "user32" (ByVal lpEnumFunc As Long, ByVal lparam As Long) As Long
	'
	'Dim nid As NOTIFYICONDATA
	'
	'Public Sub AddIcon(ByVal ToolTip As String)
	'	Try
	'		'Add icon to system tray
	'		With nid
	'			.cbSize = Len(nid)
	'			.hwnd = Me.Handle.ToInt32
	'			.uId = 0
	'			.uFlags = NIF_ICON Or NIF_TIP Or NIF_MESSAGE
	'			.uCallBackMessage = WM_MOUSEMOVE
	'			.hIcon = Me.Icon
	'			.szTip = ToolTip & vbNullChar
	'		End With
	'		Call Shell_NotifyIcon(NIM_ADD, nid)
	'
	'		Exit Sub
	'	Catch ex As Exception
	'		Cursor.Current = Cursors.Default
	'		MsgBox(Err.Description, MsgBoxStyle.Information, My.Application.Info.ProductName & " - " & Me.Text)
	'
	'	End Try
	'
	'End Sub
	'
	'Public Sub ModifyIcon(ByVal ToolTip As String)
	'	Try
	'		'Add icon to system tray
	'		With nid
	'			.cbSize = Len(nid)
	'			.hwnd = Me.Handle.ToInt32
	'			.uId = 0
	'			.uFlags = NIF_ICON Or NIF_TIP Or NIF_MESSAGE
	'			.uCallBackMessage = WM_MOUSEMOVE
	'			.hIcon = Me.Icon
	'			.szTip = ToolTip & vbNullChar
	'		End With
	'		Call Shell_NotifyIcon(NIM_MODIFY, nid)
	'
	'		Exit Sub
	'	Catch ex As Exception
	'		Cursor.Current = Cursors.Default
	'		MsgBox(Err.Description, MsgBoxStyle.Information, My.Application.Info.ProductName & " - " & Me.Text)
	'
	'	End Try
	'
	'End Sub
	'
	'Public Sub DeleteIcon(ByVal ToolTip As String)
	'	Try
	'		'Add icon to system tray
	'		With nid
	'			.cbSize = Len(nid)
	'			.hwnd = Me.Handle.ToInt32
	'			.uId = 0
	'			.uFlags = NIF_ICON Or NIF_TIP Or NIF_MESSAGE
	'			.uCallBackMessage = WM_MOUSEMOVE
	'			.hIcon = Me.Icon
	'			.szTip = ToolTip & vbNullChar
	'		End With
	'		Call Shell_NotifyIcon(NIM_DELETE, nid)
	'
	'		Exit Sub
	'	Catch ex As Exception
	'		Cursor.Current = Cursors.Default
	'		MsgBox(Err.Description, MsgBoxStyle.Information, My.Application.Info.ProductName & " - " & Me.Text)
	'
	'	End Try
	'
	'End Sub

	Private Sub Command1_Click(ByVal eventSender As Object, ByVal eventArgs As EventArgs) Handles Command1.Click
		Timer2.Enabled = True
		If FileExists(My.Application.Info.DirectoryPath & "\pack2.bat") Then
			Shell(My.Application.Info.DirectoryPath & "\pack2.bat", AppWinStyle.Hide)
		Else
			MsgBox("Can't find 'pack2.bat' and maybe also 'pack.bat'.", MsgBoxStyle.Critical, "Error!")
		End If
	End Sub

	Private Sub Command1_MouseMove(ByVal eventSender As Object, ByVal eventArgs As MouseEventArgs) Handles Command1.MouseMove
		'Dim Button As Short = eventArgs.Button \ &H100000
		'Dim Shift As Short = ModifierKeys \ &H10000
		'Dim X As Single = VB6.PixelsToTwipsX(eventArgs.X)
		'Dim Y As Single = VB6.PixelsToTwipsY(eventArgs.Y)
		Label1.Text = "This command uses kompact_new.exe to Pack koms."
	End Sub

	Private Sub Command2_Click(ByVal eventSender As Object, ByVal eventArgs As EventArgs) Handles Command2.Click
		Timer1.Enabled = True
		If FileExists(My.Application.Info.DirectoryPath & "\unpack2.bat") Then
			Shell(My.Application.Info.DirectoryPath & "\unpack2.bat", AppWinStyle.Hide)
		Else
			MsgBox("Can't find 'unpack2.bat' and maybe also 'unpack.bat'.", MsgBoxStyle.Critical, "Error!")
		End If
	End Sub

	Private Sub Command2_MouseMove(ByVal eventSender As Object, ByVal eventArgs As MouseEventArgs) Handles Command2.MouseMove
		'Dim Button As Short = eventArgs.Button \ &H100000
		'Dim Shift As Short = System.Windows.Forms.Control.ModifierKeys \ &H10000
		'Dim X As Single = VB6.PixelsToTwipsX(eventArgs.X)
		'Dim Y As Single = VB6.PixelsToTwipsY(eventArgs.Y)
		Label1.Text = "This command uses komextract_new.exe to Unpack koms."
	End Sub

	Private Sub Command3_Click(ByVal eventSender As Object, ByVal eventArgs As EventArgs) Handles Command3.Click
		Form2.ShowDialog()
	End Sub

	Private Sub Command3_MouseMove(ByVal eventSender As Object, ByVal eventArgs As MouseEventArgs) Handles Command3.MouseMove
		'Dim Button As Short = eventArgs.Button \ &H100000
		'Dim Shift As Short = System.Windows.Forms.Control.ModifierKeys \ &H10000
		'Dim X As Single = VB6.PixelsToTwipsX(eventArgs.X)
		'Dim Y As Single = VB6.PixelsToTwipsY(eventArgs.Y)
		Label1.Text = "Shows the About Window. Here you will see things like the version as well as a link to go to the topic to update Els_kom if needed."
	End Sub

	Private Sub Command4_Click(ByVal eventSender As Object, ByVal eventArgs As EventArgs) Handles Command4.Click
		'Timer6.Enabled = False
		'Command1.Enabled = False
		'Command2.Enabled = False
		'Command4.Enabled = False
		'Command5.Enabled = False
		'PackToolStripMenuItem.Enabled = False
		'UnpackToolStripMenuItem.Enabled = False
		'TestModsToolStripMenuItem.Enabled = False
		'LauncherToolStripMenuItem.Enabled = False
		If FileExists(My.Application.Info.DirectoryPath & "\Test_Mods.exe") Then
			Me.WindowState = FormWindowState.Minimized
			Label2.Text = "Testing Mods..."
			NotifyIcon1.Text = Label2.Text
			Shell(My.Application.Info.DirectoryPath & "\Test_Mods.exe")
		Else
			Me.WindowState = FormWindowState.Normal
			Label2.Text = ""
			NotifyIcon1.Text = Me.Text
			MsgBox("Can't find 'Test_Mods.exe'.", MsgBoxStyle.Critical, "Error!")
		End If
	End Sub

	Private Sub Command4_MouseMove(ByVal eventSender As Object, ByVal eventArgs As MouseEventArgs) Handles Command4.MouseMove
		'Dim Button As Short = eventArgs.Button \ &H100000
		'Dim Shift As Short = System.Windows.Forms.Control.ModifierKeys \ &H10000
		'Dim X As Single = VB6.PixelsToTwipsX(eventArgs.X)
		'Dim Y As Single = VB6.PixelsToTwipsY(eventArgs.Y)
		Label1.Text = "Test the mods you made.(kom files must be in same folder as this program as for a unknown reason.)"
	End Sub

	Private Sub Command5_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Command5.Click
		If FileExists(My.Application.Info.DirectoryPath & "\Launcher.exe") Then
			Shell(My.Application.Info.DirectoryPath & "\Launcher.exe")
		Else
			MsgBox("Can't find 'Launcher.exe'.", MsgBoxStyle.Critical, "Error!")
		End If
	End Sub

	Private Sub Command5_MouseMove(ByVal eventSender As Object, ByVal eventArgs As MouseEventArgs) Handles Command5.MouseMove
		'Dim Button As Short = eventArgs.Button \ &H100000
		'Dim Shift As Short = ModifierKeys \ &H10000
		'Dim X As Single = VB6.PixelsToTwipsX(eventArgs.X)
		'Dim Y As Single = VB6.PixelsToTwipsY(eventArgs.Y)
		Label1.Text = "Run the Launcher to Elsword to Update the client for when a server Maintenance happens.(you might have to remake some mods for some files.)"
	End Sub

	Private Sub Form1_Load(ByVal eventSender As Object, ByVal eventArgs As EventArgs) Handles MyBase.Load
		'Me.Icon = My.Resources.els_kom_icon
		'Call AddIcon(Me.Text)
		NotifyIcon1.Icon = My.Resources.els_kom_icon
		NotifyIcon1.Text = Me.Text
	End Sub

	Private Sub Form1_MouseMove(ByVal eventSender As Object, ByVal eventArgs As MouseEventArgs) Handles MyBase.MouseMove
		'Dim Button As Short = eventArgs.Button \ &H100000
		'Dim Shift As Short = ModifierKeys \ &H10000
		'Dim X As Single = VB6.PixelsToTwipsX(eventArgs.X)
		'Dim Y As Single = VB6.PixelsToTwipsY(eventArgs.Y)
		Label1.Text = ""
		'Dim msg As Integer
		'
		'Try
		'
		'	'Respond to user interaction
		'	'	msg = X / VB6.TwipsPerPixelX
		'	Select Case msg
		'
		'		Case WM_LBUTTONDBLCLK
		'			'nothing
		'
		'		Case WM_LBUTTONDOWN
		'			'nothing
		'
		'		Case WM_LBUTTONUP
		'			If Me.WindowState = FormWindowState.Minimized Then
		'				Me.WindowState = FormWindowState.Normal
		'				'Me.Show
		'				'Me.ShowInTaskbar = True
		'			Else
		'				Me.WindowState = System.Windows.Forms.FormWindowState.Minimized
		'				'Me.Hide
		'				'Me.ShowInTaskbar = True
		'			End If
		'
		'		Case WM_RBUTTONDBLCLK
		'			'nothing
		'
		'		Case WM_RBUTTONDOWN
		'			'nothing

		'		Case WM_RBUTTONUP
		'			'UPGRADE_ISSUE: Constant vbPopupMenuRightAlign was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'			'UPGRADE_ISSUE: Form method Form1.PopupMenu was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
		'			' TODO: Read menu later.

		'			'Call PopupMenu(Form3.mnuShell, vbPopupMenuRightAlign)
		'End Select
		'Exit Sub
		'Catch ex As Exception
		'	Cursor.Current = Cursors.Default
		'	MsgBox(Err.Description, MsgBoxStyle.Information, My.Application.Info.ProductName & " - " & Me.Text)
		'
		'End Try

	End Sub

	Private Sub Form1_FormClosing(ByVal eventSender As Object, ByVal eventArgs As FormClosingEventArgs) Handles Me.FormClosing
		Dim Cancel As Boolean = eventArgs.Cancel
		Dim UnloadMode As CloseReason = eventArgs.CloseReason
		'Call DeleteIcon(Me.Text)
		eventArgs.Cancel = Cancel
	End Sub

	Private Sub Timer1_Tick(ByVal eventSender As Object, ByVal eventArgs As EventArgs) Handles Timer1.Tick
		If FileExists(My.Application.Info.DirectoryPath & "\unpacking.unpack") Then
			Timer6.Enabled = False
			Command1.Enabled = False
			Command2.Enabled = False
			Command4.Enabled = False
			Command5.Enabled = False
			PackToolStripMenuItem.Enabled = False
			UnpackToolStripMenuItem.Enabled = False
			TestModsToolStripMenuItem.Enabled = False
			LauncherToolStripMenuItem.Enabled = False
			Label2.Text = "Unpacking..."
			NotifyIcon1.Text = Label2.Text
			'Call ModifyIcon(Label2.Text)
		Else
			Timer6.Enabled = True
			Command1.Enabled = True
			Command2.Enabled = True
			Command4.Enabled = True
			Command5.Enabled = True
			PackToolStripMenuItem.Enabled = True
			UnpackToolStripMenuItem.Enabled = True
			TestModsToolStripMenuItem.Enabled = True
			LauncherToolStripMenuItem.Enabled = True
			Label2.Text = ""
			NotifyIcon1.Text = Me.Text
			'Call ModifyIcon(Me.Text)
		End If
	End Sub

	Private Sub Timer2_Tick(ByVal eventSender As Object, ByVal eventArgs As EventArgs) Handles Timer2.Tick
		If FileExists(My.Application.Info.DirectoryPath & "\packing.pack") Then
			Timer6.Enabled = False
			Command1.Enabled = False
			Command2.Enabled = False
			Command4.Enabled = False
			Command5.Enabled = False
			PackToolStripMenuItem.Enabled = False
			UnpackToolStripMenuItem.Enabled = False
			TestModsToolStripMenuItem.Enabled = False
			LauncherToolStripMenuItem.Enabled = False
			Label2.Text = "Packing..."
			NotifyIcon1.Text = Label2.Text
			'Call ModifyIcon(Label2.Text)
		Else
			Timer6.Enabled = True
			Command1.Enabled = True
			Command2.Enabled = True
			Command4.Enabled = True
			Command5.Enabled = True
			PackToolStripMenuItem.Enabled = True
			UnpackToolStripMenuItem.Enabled = True
			TestModsToolStripMenuItem.Enabled = True
			LauncherToolStripMenuItem.Enabled = True
			Label2.Text = ""
			NotifyIcon1.Text = Me.Text
			'Call ModifyIcon(Me.Text)
		End If
	End Sub

	Private Sub Timer6_Tick(ByVal eventSender As Object, ByVal eventArgs As EventArgs) Handles Timer6.Tick
		If Me.WindowState = FormWindowState.Normal Then
			Me.Height = 184
			Me.Width = 320
		End If
		If FileExists(My.Application.Info.DirectoryPath & "\Launcher.exe") Then
			LauncherToolStripMenuItem.Enabled = True
			Command5.Enabled = True
		Else
			LauncherToolStripMenuItem.Enabled = False
			Command5.Enabled = False
		End If
		If FileExists(My.Application.Info.DirectoryPath & "\Test_Mods.exe") Then
			TestModsToolStripMenuItem.Enabled = True
			Command4.Enabled = True
		Else
			TestModsToolStripMenuItem.Enabled = False
			Command4.Enabled = False
		End If
	End Sub

	Private Sub NotifyIcon1_MouseClick(sender As Object, e As MouseEventArgs) Handles NotifyIcon1.MouseClick
		If e.Button = MouseButtons.Left Then
			If Me.WindowState = FormWindowState.Minimized Then
				Me.WindowState = FormWindowState.Normal
				'Me.Show()
				'Me.ShowInTaskbar = True
			Else
				Me.WindowState = FormWindowState.Minimized
				'Me.Hide
				'Me.ShowInTaskbar = True
			End If
		ElseIf e.Button = MouseButtons.Right Then
			' Well then this means the menu is showing.
		End If
	End Sub

	Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
		Timer1.Enabled = False
		Timer2.Enabled = False
		Timer6.Enabled = False
		Form2.Close()
		Me.Close()
	End Sub

	Private Sub LauncherToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LauncherToolStripMenuItem.Click
		'Timer6.Enabled = False
		'Command1.Enabled = False
		'Command2.Enabled = False
		'Command4.Enabled = False
		'Command5.Enabled = False
		'PackToolStripMenuItem.Enabled = False
		'UnpackToolStripMenuItem.Enabled = False
		'TestModsToolStripMenuItem.Enabled = False
		'LauncherToolStripMenuItem.Enabled = False
		WindowState = FormWindowState.Minimized
		'Form1.Timer3.Enabled = True
		If FileExists(My.Application.Info.DirectoryPath & "\Launcher.exe") Then
			Shell(My.Application.Info.DirectoryPath & "\Launcher.exe")
		Else
			MsgBox("Can't find 'Launcher.exe'.", MsgBoxStyle.Critical, "Error!")
		End If
	End Sub

	Private Sub UnpackToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UnpackToolStripMenuItem.Click
		Timer1.Enabled = True
		If FileExists(My.Application.Info.DirectoryPath & "\unpack2.bat") Then
			Shell(My.Application.Info.DirectoryPath & "\unpack2.bat", AppWinStyle.Hide)
		Else
			MsgBox("Can't find 'unpack2.bat' and maybe also 'unpack.bat'.", MsgBoxStyle.Critical, "Error!")
		End If
	End Sub

	Private Sub TestModsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TestModsToolStripMenuItem.Click
		'Timer6.Enabled = False
		'Command1.Enabled = False
		'Command2.Enabled = False
		'Command4.Enabled = False
		'Command5.Enabled = False
		'PackToolStripMenuItem.Enabled = False
		'UnpackToolStripMenuItem.Enabled = False
		'TestModsToolStripMenuItem.Enabled = False
		'LauncherToolStripMenuItem.Enabled = False
		If FileExists(My.Application.Info.DirectoryPath & "\Test_Mods.exe") Then
			Me.WindowState = FormWindowState.Minimized
			Label2.Text = "Testing Mods..."
			NotifyIcon1.Text = Label2.Text
			Shell(My.Application.Info.DirectoryPath & "\Test_Mods.exe")
		Else
			Me.WindowState = FormWindowState.Normal
			Label2.Text = ""
			NotifyIcon1.Text = Me.Text
			MsgBox("Can't find 'Test_Mods.exe'.", MsgBoxStyle.Critical, "Error!")
		End If
	End Sub

	Private Sub PackToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PackToolStripMenuItem.Click
		Timer2.Enabled = True
		If FileExists(My.Application.Info.DirectoryPath & "\pack2.bat") Then
			Shell(My.Application.Info.DirectoryPath & "\pack2.bat", AppWinStyle.Hide)
		Else
			MsgBox("Can't find 'pack2.bat' and maybe also 'pack.bat'.", MsgBoxStyle.Critical, "Error!")
		End If
	End Sub
End Class