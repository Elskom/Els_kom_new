Option Strict Off
Option Explicit On
Imports Microsoft.VisualBasic.PowerPacks
Friend Class Form2
	Inherits System.Windows.Forms.Form
	Private Declare Function ShellExecute Lib "shell32.dll"  Alias "ShellExecuteA"(ByVal hwnd As Integer, ByVal lpOperation As String, ByVal lpFile As String, ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Integer) As Integer

	' Open the default browser on a given URL
	' Returns True if successful, False otherwise
	Public Function OpenBrowser(ByVal URL As String) As Boolean
		Dim res As Integer
		' it is mandatory that the URL is prefixed with http:// or https://
		If InStr(1, URL, "http", CompareMethod.Text) <> 1 Then
			URL = "http://" & URL
		End If
		res = ShellExecute(0, "open", URL, vbNullString, vbNullString, AppWinStyle.NormalFocus)
		OpenBrowser = (res > 32)
	End Function

	Private Sub cmdOK_Click(ByVal eventSender As Object, ByVal eventArgs As EventArgs) Handles cmdOK.Click
		Me.Close()
	End Sub

	Private Sub Form2_Load(ByVal eventSender As Object, ByVal eventArgs As EventArgs) Handles MyBase.Load
		Me.Icon = My.Resources.els_kom_icon
		picIcon.Image = My.Resources.els_kom
		Picture1.Image = My.Resources.bmp100
		Picture2.Image = My.Resources.bmp101
	End Sub

	Private Sub Form2_MouseMove(ByVal eventSender As Object, ByVal eventArgs As MouseEventArgs) Handles MyBase.MouseMove
		Dim Button As Short = eventArgs.Button \ &H100000
		Dim Shift As Short = ModifierKeys \ &H10000
		Dim X As Single = VB6.FromPixelsUserX(eventArgs.X, 0, 5125.82, 382)
		Dim Y As Single = VB6.FromPixelsUserY(eventArgs.Y, 0, 3855, 257)
		Picture1.Visible = True
		Picture2.Visible = False
	End Sub

	Private Sub Picture1_MouseMove(ByVal eventSender As Object, ByVal eventArgs As MouseEventArgs) Handles Picture1.MouseMove
		Dim Button As Short = eventArgs.Button \ &H100000
		Dim Shift As Short = ModifierKeys \ &H10000
		Dim X As Single = VB6.PixelsToTwipsX(eventArgs.X)
		Dim Y As Single = VB6.PixelsToTwipsY(eventArgs.Y)
		Picture1.Visible = False
		Picture2.Visible = True
	End Sub

	Private Sub Picture2_Click(ByVal eventSender As Object, ByVal eventArgs As EventArgs) Handles Picture2.Click
		Picture1.Visible = True
		Picture2.Visible = False
		OpenBrowser("www.elsword.to/forum/index.php?/topic/51000-updated-els-kom-v1490-working-as-of-8-6-16/")
	End Sub
End Class